"""Isolated Blender worker for deterministic asset observation and MAIN preview."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Callable, Iterable

SUPPORTED_PROFILES = ("PREVIEW", "METADATA", "PUBLISH")
WORKER_PROTOCOL_VERSION = 4
OBSERVATION_SCHEMA_VERSION = 1
ANALYZER_VERSION = "blender-mcp-observation-v1"
PREVIEW_PRESET_VERSION = "asset-preview-v2"
OBJECT_DETAIL_LIMIT = 50
MATERIAL_DETAIL_LIMIT = 30
PREVIEW_WIDTH = 512
PREVIEW_HEIGHT = 512
SUPPLEMENTAL_VIEWS = ("FRONT", "BACK", "LEFT", "RIGHT", "TOP")
PUBLISH_DIMENSION_TOLERANCE_METERS = 1e-5


class PublishValidationError(RuntimeError):
    """Stable failure raised when a prepared publish payload is not trustworthy."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)

_NON_PBR_SHADER_TYPES = {
    "BSDF_DIFFUSE",
    "BSDF_GLASS",
    "BSDF_GLOSSY",
    "BSDF_HAIR",
    "BSDF_HAIR_PRINCIPLED",
    "BSDF_REFRACTION",
    "BSDF_TOON",
    "BSDF_TRANSPARENT",
    "EMISSION",
    "SUBSURFACE_SCATTERING",
}
_SHADER_GRAPH_TYPES = _NON_PBR_SHADER_TYPES | {
    "BSDF_PRINCIPLED",
    "MIX_SHADER",
    "ADD_SHADER",
}
_PBR_INPUT_CHANNELS = {
    "Base Color": "base_color",
    "Metallic": "metallic",
    "Roughness": "roughness",
    "Normal": "normal",
    "Alpha": "alpha",
    "Emission Color": "emission",
    "Emission": "emission",
}
_LOD_RE = re.compile(r"(?:^|[_ .-])LOD(\d+)(?:$|[_ .-])", re.IGNORECASE)


def _import_bpy():
    import bpy  # type: ignore

    return bpy


def _elapsed_ms(started: float) -> float:
    return round((time.perf_counter() - started) * 1000.0, 3)


def _bounded(items: list[dict[str, Any]], limit: int) -> dict[str, Any]:
    bounded_limit = max(0, int(limit))
    return {
        "totalCount": len(items),
        "truncated": len(items) > bounded_limit,
        "items": items[:bounded_limit],
    }


def _as_sequence(value: Any) -> list[Any]:
    if value is None:
        return []
    values = getattr(value, "values", None)
    if callable(values):
        try:
            return list(values())
        except Exception:
            pass
    try:
        return list(value)
    except TypeError:
        return []


def _get_input(node: Any, name: str) -> Any | None:
    inputs = getattr(node, "inputs", None)
    if inputs is None:
        return None
    getter = getattr(inputs, "get", None)
    if callable(getter):
        try:
            found = getter(name)
            if found is not None:
                return found
        except Exception:
            pass
    for socket in _as_sequence(inputs):
        if getattr(socket, "name", None) == name:
            return socket
    return None


def _iter_inputs(node: Any) -> list[Any]:
    return _as_sequence(getattr(node, "inputs", None))


def _socket_links(socket: Any) -> list[Any]:
    if socket is None:
        return []
    try:
        if hasattr(socket, "is_linked") and not socket.is_linked:
            return []
    except Exception:
        pass
    return _as_sequence(getattr(socket, "links", None))


def _node_type(node: Any) -> str:
    return str(getattr(node, "type", None) or getattr(node, "bl_idname", "UNKNOWN"))


def _connected_nodes_from_socket(socket: Any) -> list[Any]:
    """Return only nodes contributing to the linked socket, breadth-first."""
    pending = []
    for link in _socket_links(socket):
        from_node = getattr(link, "from_node", None)
        if from_node is not None:
            pending.append(from_node)

    ordered: list[Any] = []
    seen: set[int] = set()
    while pending:
        node = pending.pop(0)
        identity = id(node)
        if identity in seen:
            continue
        seen.add(identity)
        ordered.append(node)
        for input_socket in _iter_inputs(node):
            for link in _socket_links(input_socket):
                from_node = getattr(link, "from_node", None)
                if from_node is not None:
                    pending.append(from_node)
    return ordered


def _active_material_output(material: Any) -> Any | None:
    node_tree = getattr(material, "node_tree", None)
    outputs = [
        node
        for node in _as_sequence(getattr(node_tree, "nodes", None))
        if _node_type(node) == "OUTPUT_MATERIAL"
    ]
    if not outputs:
        return None
    for output in outputs:
        if bool(getattr(output, "is_active_output", False)):
            return output
    return outputs[0]


def _socket_default(socket: Any, fallback: Any = None) -> Any:
    if socket is None:
        return fallback
    return getattr(socket, "default_value", fallback)


def _float_value(value: Any) -> float | None:
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        return None


def _color_value(value: Any) -> list[float] | None:
    try:
        values = [round(float(component), 6) for component in value]
    except (TypeError, ValueError):
        return None
    return values[:4] if values else None


def _texture_usages(principled_nodes: Iterable[Any]) -> list[dict[str, Any]]:
    usages: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for principled in principled_nodes:
        for input_name, channel in _PBR_INPUT_CHANNELS.items():
            socket = _get_input(principled, input_name)
            if socket is None:
                continue
            for node in _connected_nodes_from_socket(socket):
                if _node_type(node) != "TEX_IMAGE":
                    continue
                image = getattr(node, "image", None)
                if image is None:
                    continue
                image_name = str(getattr(image, "name", ""))
                identity = (channel, image_name)
                if identity in seen:
                    continue
                seen.add(identity)
                size = _as_sequence(getattr(image, "size", None))
                usage: dict[str, Any] = {
                    "channel": channel,
                    "imageName": image_name or None,
                }
                if len(size) >= 2:
                    try:
                        usage["width"] = int(size[0])
                        usage["height"] = int(size[1])
                    except (TypeError, ValueError):
                        pass
                usages.append(usage)
    usages.sort(key=lambda item: (item["channel"], item.get("imageName") or ""))
    return usages


def classify_material(material: Any) -> dict[str, Any]:
    """Classify the shader graph that actually feeds the active Material Output."""
    name = str(getattr(material, "name", "Material"))
    if not bool(getattr(material, "use_nodes", False)):
        return {
            "name": name,
            "usesNodes": False,
            "shaderTypes": [],
            "textureUsages": [],
            "workflow": "NON_PBR",
            "pbrChannels": [],
        }

    output = _active_material_output(material)
    surface = _get_input(output, "Surface") if output is not None else None
    connected = _connected_nodes_from_socket(surface)
    connected_types = [_node_type(node) for node in connected]
    shader_types = sorted({kind for kind in connected_types if kind in _SHADER_GRAPH_TYPES})
    principled = [node for node in connected if _node_type(node) == "BSDF_PRINCIPLED"]
    has_non_pbr = any(kind in _NON_PBR_SHADER_TYPES for kind in connected_types)

    if principled and has_non_pbr:
        workflow = "MIXED"
    elif principled:
        workflow = "PBR"
    elif has_non_pbr:
        workflow = "NON_PBR"
    else:
        workflow = "UNKNOWN"

    result: dict[str, Any] = {
        "name": name,
        "usesNodes": True,
        "shaderTypes": shader_types,
        "textureUsages": _texture_usages(principled),
        "workflow": workflow,
        "pbrChannels": [],
    }
    if principled:
        primary = principled[0]
        base_color = _color_value(_socket_default(_get_input(primary, "Base Color")))
        metallic = _float_value(_socket_default(_get_input(primary, "Metallic")))
        roughness = _float_value(_socket_default(_get_input(primary, "Roughness")))
        if base_color is not None:
            result["baseColor"] = base_color
            result["pbrChannels"].append("base_color")
        if metallic is not None:
            result["metallic"] = metallic
            result["pbrChannels"].append("metallic")
        if roughness is not None:
            result["roughness"] = roughness
            result["pbrChannels"].append("roughness")
        for usage in result["textureUsages"]:
            if usage["channel"] not in result["pbrChannels"]:
                result["pbrChannels"].append(usage["channel"])
        result["pbrChannels"].sort()
    return result


def aggregate_material_workflow(workflows: Iterable[str]) -> str:
    values = [str(value) for value in workflows]
    if not values:
        return "UNKNOWN"
    unique = set(values)
    if unique == {"PBR"}:
        return "PBR"
    if unique == {"NON_PBR"}:
        return "NON_PBR"
    if unique == {"UNKNOWN"}:
        return "UNKNOWN"
    if "MIXED" in unique or len(unique) > 1:
        return "MIXED"
    return "UNKNOWN"


def _object_materials(obj: Any) -> list[Any]:
    materials: list[Any] = []
    seen: set[int] = set()
    data = getattr(obj, "data", None)
    for material in _as_sequence(getattr(data, "materials", None)):
        if material is not None and id(material) not in seen:
            seen.add(id(material))
            materials.append(material)
    for slot in _as_sequence(getattr(obj, "material_slots", None)):
        material = getattr(slot, "material", None)
        if material is not None and id(material) not in seen:
            seen.add(id(material))
            materials.append(material)
    return materials


def _object_dimensions(obj: Any, scale_length: float) -> dict[str, float] | None:
    dimensions = getattr(obj, "dimensions", None)
    if dimensions is None:
        return None
    values = _as_sequence(dimensions)
    if len(values) < 3:
        return None
    try:
        return {
            "x": round(abs(float(values[0])) * scale_length, 6),
            "y": round(abs(float(values[1])) * scale_length, 6),
            "z": round(abs(float(values[2])) * scale_length, 6),
        }
    except (TypeError, ValueError):
        return None


def _default_mesh_inspector(obj: Any, scale_length: float) -> dict[str, Any]:
    mesh = getattr(obj, "data", None)
    vertices = len(getattr(mesh, "vertices", ()) or ()) if mesh is not None else 0
    edges = len(getattr(mesh, "edges", ()) or ()) if mesh is not None else 0
    polygons = len(getattr(mesh, "polygons", ()) or ()) if mesh is not None else 0
    triangles = 0
    for polygon in getattr(mesh, "polygons", ()) or ():
        loop_total = int(getattr(polygon, "loop_total", 0) or 0)
        triangles += max(0, loop_total - 2)
    dimensions = _object_dimensions(obj, scale_length) or {"x": 0.0, "y": 0.0, "z": 0.0}
    bounds = [[0.0, 0.0, 0.0], [dimensions["x"], dimensions["y"], dimensions["z"]]]
    return {
        "vertices": vertices,
        "edges": edges,
        "polygons": polygons,
        "triangles": triangles,
        "hasUv": bool(getattr(mesh, "uv_layers", None)),
        "boundsMeters": bounds,
        "dimensionsMeters": dimensions,
    }


def summarize_objects(
    objects: Iterable[Any],
    *,
    scale_length: float,
    detail_limit: int = OBJECT_DETAIL_LIMIT,
    mesh_inspector: Callable[[Any, float], dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Aggregate every object while bounding only the returned detail list."""
    ordered = sorted(list(objects), key=lambda obj: str(getattr(obj, "name", "")))
    inspect_mesh = mesh_inspector or _default_mesh_inspector
    details: list[dict[str, Any]] = []
    mesh_count = vertex_count = edge_count = polygon_count = triangle_count = 0
    has_uv = False
    lod_levels: set[int] = set()
    bounds_min: list[float] | None = None
    bounds_max: list[float] | None = None

    for obj in ordered:
        name = str(getattr(obj, "name", ""))
        obj_type = str(getattr(obj, "type", "UNKNOWN"))
        detail: dict[str, Any] = {"name": name, "type": obj_type}
        dimensions = _object_dimensions(obj, scale_length)
        if dimensions is not None:
            detail["dimensionsMeters"] = dimensions
        modifiers = sorted(
            {
                str(getattr(modifier, "type", "UNKNOWN"))
                for modifier in _as_sequence(getattr(obj, "modifiers", None))
            }
        )
        if modifiers:
            detail["modifiers"] = modifiers
        material_names = sorted(
            {str(getattr(material, "name", "")) for material in _object_materials(obj)}
        )
        if material_names:
            detail["materialNames"] = material_names

        lod_match = _LOD_RE.search(name)
        if lod_match:
            lod_levels.add(int(lod_match.group(1)))

        if obj_type == "MESH":
            mesh_count += 1
            stats = inspect_mesh(obj, scale_length)
            vertices = int(stats.get("vertices", 0) or 0)
            edges = int(stats.get("edges", 0) or 0)
            polygons = int(stats.get("polygons", 0) or 0)
            triangles = int(stats.get("triangles", 0) or 0)
            vertex_count += vertices
            edge_count += edges
            polygon_count += polygons
            triangle_count += triangles
            has_uv = has_uv or bool(stats.get("hasUv", False))
            detail["meshStats"] = {"vertices": vertices, "triangles": triangles}
            if stats.get("dimensionsMeters") is not None:
                detail["dimensionsMeters"] = stats["dimensionsMeters"]
            bounds = stats.get("boundsMeters")
            if bounds and len(bounds) >= 2:
                low = [float(component) for component in bounds[0][:3]]
                high = [float(component) for component in bounds[1][:3]]
                if bounds_min is None:
                    bounds_min = low
                    bounds_max = high
                else:
                    bounds_min = [min(bounds_min[i], low[i]) for i in range(3)]
                    bounds_max = [max(bounds_max[i], high[i]) for i in range(3)]
        details.append(detail)

    if bounds_min is None or bounds_max is None:
        dimensions = {"x": 0.0, "y": 0.0, "z": 0.0}
        normalized_bounds = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
    else:
        extents = [max(0.0, bounds_max[i] - bounds_min[i]) for i in range(3)]
        dimensions = {
            "x": round(extents[0], 6),
            "y": round(extents[1], 6),
            "z": round(extents[2], 6),
        }
        normalized_bounds = [
            [0.0, 0.0, 0.0],
            [dimensions["x"], dimensions["y"], dimensions["z"]],
        ]

    structure = {
        "objectCount": len(ordered),
        "objects": _bounded(details, detail_limit),
    }
    geometry = {
        "meshCount": mesh_count,
        "vertexCount": vertex_count,
        "edgeCount": edge_count,
        "polygonCount": polygon_count,
        "triangleCount": triangle_count,
        "dimensionsMeters": dimensions,
        "boundingBox": normalized_bounds,
        "hasUv": has_uv,
        "lodCount": len(lod_levels),
    }
    return structure, geometry


def summarize_materials(
    objects: Iterable[Any], *, detail_limit: int = MATERIAL_DETAIL_LIMIT
) -> tuple[dict[str, Any], list[str]]:
    materials: list[Any] = []
    seen: set[int] = set()
    for obj in objects:
        for material in _object_materials(obj):
            if id(material) not in seen:
                seen.add(id(material))
                materials.append(material)
    materials.sort(key=lambda value: str(getattr(value, "name", "")))

    classified = [classify_material(material) for material in materials]
    workflows = [item["workflow"] for item in classified]
    pbr_channels = sorted(
        {channel for item in classified for channel in item.get("pbrChannels", [])}
    )
    image_names = {
        usage.get("imageName")
        for item in classified
        for usage in item.get("textureUsages", [])
        if usage.get("imageName")
    }
    public_items: list[dict[str, Any]] = []
    for item in classified:
        public_item = dict(item)
        public_item.pop("workflow", None)
        public_item.pop("pbrChannels", None)
        public_items.append(public_item)

    return (
        {
            "materialCount": len(materials),
            "textureCount": len(image_names),
            "items": _bounded(public_items, detail_limit),
            "materialWorkflow": aggregate_material_workflow(workflows),
            "pbrChannels": pbr_channels,
        },
        [str(getattr(material, "name", "")) for material in materials],
    )


def summarize_deformation(objects: Iterable[Any]) -> dict[str, Any]:
    ordered = list(objects)
    armatures = [obj for obj in ordered if str(getattr(obj, "type", "")) == "ARMATURE"]
    rigged = bool(armatures)
    action_ids: set[int] = set()
    animated = False
    shape_key_count = 0

    for obj in ordered:
        for modifier in _as_sequence(getattr(obj, "modifiers", None)):
            if str(getattr(modifier, "type", "")) == "ARMATURE":
                rigged = True
        for owner in (obj, getattr(obj, "data", None)):
            animation_data = getattr(owner, "animation_data", None)
            if animation_data is None:
                continue
            action = getattr(animation_data, "action", None)
            if action is not None:
                action_ids.add(id(action))
                animated = True
            for track in _as_sequence(getattr(animation_data, "nla_tracks", None)):
                strips = _as_sequence(getattr(track, "strips", None))
                if strips or track is not None:
                    animated = True
                for strip in strips:
                    strip_action = getattr(strip, "action", None)
                    if strip_action is not None:
                        action_ids.add(id(strip_action))
        shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
        key_blocks = _as_sequence(getattr(shape_keys, "key_blocks", None))
        if key_blocks:
            shape_key_count += max(0, len(key_blocks) - 1)
            if len(key_blocks) > 1:
                animated = animated or bool(getattr(shape_keys, "animation_data", None))

    return {
        "rigged": rigged,
        "animated": animated,
        "armatureCount": len(armatures),
        "actionCount": len(action_ids),
        "shapeKeyCount": shape_key_count,
    }


def _file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _real_mesh_inspector(bpy: Any) -> Callable[[Any, float], dict[str, Any]]:
    depsgraph = bpy.context.evaluated_depsgraph_get()
    from mathutils import Vector  # type: ignore

    def inspect(obj: Any, scale_length: float) -> dict[str, Any]:
        evaluated = obj.evaluated_get(depsgraph)
        try:
            mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
        except TypeError:
            mesh = evaluated.to_mesh()
        try:
            mesh.calc_loop_triangles()
            points = [evaluated.matrix_world @ Vector(vertex.co) for vertex in mesh.vertices]
            if points:
                low = [min(point[index] for point in points) * scale_length for index in range(3)]
                high = [max(point[index] for point in points) * scale_length for index in range(3)]
            else:
                low = [0.0, 0.0, 0.0]
                high = [0.0, 0.0, 0.0]
            dimensions = {
                "x": round(max(0.0, high[0] - low[0]), 6),
                "y": round(max(0.0, high[1] - low[1]), 6),
                "z": round(max(0.0, high[2] - low[2]), 6),
            }
            return {
                "vertices": len(mesh.vertices),
                "edges": len(mesh.edges),
                "polygons": len(mesh.polygons),
                "triangles": len(mesh.loop_triangles),
                "hasUv": len(mesh.uv_layers) > 0,
                "boundsMeters": [
                    [round(float(value), 6) for value in low],
                    [round(float(value), 6) for value in high],
                ],
                "dimensionsMeters": dimensions,
            }
        finally:
            evaluated.to_mesh_clear()

    return inspect


def _unit_name(scale_length: float) -> str:
    """Name the authoring unit without touching geometry (1 unit = scale_length meters)."""
    known = {1.0: "METERS", 0.01: "CENTIMETERS", 0.001: "MILLIMETERS"}
    for value, name in known.items():
        if abs(scale_length - value) <= 1e-9:
            return name
    return f"CUSTOM:{scale_length:g}"


def extract_observation(
    bpy: Any,
    *,
    prepare_id: str,
    source_kind: str,
    source_path: str,
    profile: str,
    object_detail_limit: int = OBJECT_DETAIL_LIMIT,
    material_detail_limit: int = MATERIAL_DETAIL_LIMIT,
    objects: Iterable[Any] | None = None,
    observation_scope: str = "SOURCE_ASSET",
    source_display_name: str | None = None,
) -> dict[str, Any]:
    """Extract deterministic facts for either source or standardized publish scope."""
    observed_objects = sorted(
        list(bpy.data.objects) if objects is None else list(objects),
        key=lambda obj: obj.name,
    )
    scene = bpy.context.scene
    unit_settings = getattr(scene, "unit_settings", None)
    scale_length = float(getattr(unit_settings, "scale_length", 1.0) or 1.0)
    structure, geometry = summarize_objects(
        observed_objects,
        scale_length=scale_length,
        detail_limit=object_detail_limit,
        mesh_inspector=_real_mesh_inspector(bpy),
    )
    structure["collectionCount"] = len(bpy.data.collections)
    materials, material_names = summarize_materials(
        observed_objects, detail_limit=material_detail_limit
    )
    deformation = summarize_deformation(observed_objects)
    source = Path(source_path)
    display_name = source_display_name or source.name

    return {
        "schemaVersion": OBSERVATION_SCHEMA_VERSION,
        "analyzerVersion": ANALYZER_VERSION,
        "prepareId": prepare_id,
        "profile": profile,
        "observationScope": observation_scope,
        "source": {
            "kind": source_kind,
            "displayName": display_name,
            "fileName": display_name,
            "sourceSize": source.stat().st_size,
            "sourceSha256": _file_sha256(source),
            "blenderVersion": bpy.app.version_string,
        },
        "structure": structure,
        "geometry": geometry,
        "units": {
            "scaleLength": scale_length,
            "name": _unit_name(scale_length),
            "lengthUnit": str(getattr(unit_settings, "length_unit", "") or ""),
            "system": str(getattr(unit_settings, "system", "") or ""),
        },
        "materials": materials,
        "deformation": deformation,
        "evidenceSummary": {
            "objectNames": [obj.name for obj in observed_objects],
            "materialNames": material_names,
        },
    }


def _collection_objects(collection: Any) -> list[Any]:
    all_objects = getattr(collection, "all_objects", None)
    if all_objects is not None:
        return _as_sequence(all_objects)
    return _as_sequence(getattr(collection, "objects", None))


def _publish_target_objects(bpy: Any) -> list[Any]:
    """Resolve one intended asset closure without treating scene cameras/lights as content."""
    root = bpy.data.collections.get("ASSET_ROOT")
    if root is not None:
        rooted = _collection_objects(root)
        if rooted:
            return sorted(rooted, key=lambda obj: obj.name)

    asset_collections = [
        collection
        for collection in bpy.data.collections
        if getattr(collection, "asset_data", None) is not None
    ]
    if len(asset_collections) == 1:
        rooted = _collection_objects(asset_collections[0])
        if rooted:
            return sorted(rooted, key=lambda obj: obj.name)

    asset_objects = [
        obj for obj in bpy.data.objects if getattr(obj, "asset_data", None) is not None
    ]
    if len(asset_objects) == 1:
        pending = [asset_objects[0]]
        resolved: dict[int, Any] = {}
        while pending:
            obj = pending.pop(0)
            if id(obj) in resolved:
                continue
            resolved[id(obj)] = obj
            pending.extend(_as_sequence(getattr(obj, "children", None)))
            for modifier in _as_sequence(getattr(obj, "modifiers", None)):
                target = getattr(modifier, "object", None)
                if target is not None:
                    pending.append(target)
            for constraint in _as_sequence(getattr(obj, "constraints", None)):
                target = getattr(constraint, "target", None)
                if target is not None:
                    pending.append(target)
        return sorted(resolved.values(), key=lambda obj: obj.name)

    fallback = [
        obj
        for obj in bpy.data.objects
        if obj.type not in {"CAMERA", "LIGHT"}
        and not obj.name.startswith("__BLENDERMCP_PREVIEW")
    ]
    return sorted(fallback, key=lambda obj: obj.name)


def _evaluated_bounds(bpy: Any, objects: Iterable[Any]) -> tuple[Any, Any] | None:
    from mathutils import Vector  # type: ignore

    depsgraph = bpy.context.evaluated_depsgraph_get()
    points = []
    for obj in objects:
        if obj.type != "MESH":
            continue
        evaluated = obj.evaluated_get(depsgraph)
        try:
            mesh = evaluated.to_mesh()
            points.extend(evaluated.matrix_world @ Vector(vertex.co) for vertex in mesh.vertices)
        finally:
            evaluated.to_mesh_clear()
    if not points:
        return None
    low = Vector(tuple(min(point[index] for point in points) for index in range(3)))
    high = Vector(tuple(max(point[index] for point in points) for index in range(3)))
    return low, high


def _is_unit_scale(obj: Any, *, tolerance: float = 1e-8) -> bool:
    values = _as_sequence(getattr(obj, "scale", None))
    return len(values) >= 3 and all(abs(float(values[index]) - 1.0) <= tolerance for index in range(3))


def _has_deformation_or_animation(obj: Any) -> bool:
    if str(getattr(obj, "type", "")) == "ARMATURE":
        return True
    for owner in (obj, getattr(obj, "data", None)):
        if owner is not None and getattr(owner, "animation_data", None) is not None:
            return True
    data = getattr(obj, "data", None)
    if getattr(data, "shape_keys", None) is not None:
        return True
    if any(
        str(getattr(modifier, "type", "")) == "ARMATURE"
        for modifier in _as_sequence(getattr(obj, "modifiers", None))
    ):
        return True
    return bool(_as_sequence(getattr(obj, "constraints", None)))


def _apply_publish_object_scales(bpy: Any, targets: list[Any]) -> None:
    """Normalize safe static scales while preserving hierarchy and deforming source transforms."""
    target_ids = {id(obj) for obj in targets}
    for obj in targets:
        if _is_unit_scale(obj):
            continue

        # Applying scale to Armatures, animated objects, constrained objects, shape-key
        # meshes, or Armature-deformed meshes can alter the evaluated animation/rig.
        # Keeping their authored object transforms is lossless and the publish payload
        # is verified after reopen, so preserve those source scales instead of failing.
        if _has_deformation_or_animation(obj):
            continue

        target_children = [
            child
            for child in _as_sequence(getattr(obj, "children", None))
            if id(child) in target_ids
        ]
        child_world_matrices = [
            (child, child.matrix_world.copy())
            for child in target_children
            if getattr(child, "matrix_world", None) is not None
        ]

        if str(getattr(obj, "type", "")) == "EMPTY":
            obj.scale = (1.0, 1.0, 1.0)
            for child, matrix_world in child_world_matrices:
                child.matrix_world = matrix_world
            continue
        if str(getattr(obj, "type", "")) != "MESH":
            raise PublishValidationError(
                "PUBLISH_SCALE_NORMALIZATION_UNSUPPORTED",
                f"Cannot safely apply non-unit scale on {obj.type} object {obj.name!r}",
            )

        from mathutils import Matrix  # type: ignore

        scale = tuple(float(value) for value in obj.scale)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = obj.evaluated_get(depsgraph)
        try:
            baked_mesh = bpy.data.meshes.new_from_object(
                evaluated,
                preserve_all_data_layers=True,
                depsgraph=depsgraph,
            )
        except TypeError:
            baked_mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
        baked_mesh.name = f"{obj.data.name}_PUBLISH"
        baked_mesh.transform(Matrix.Diagonal((scale[0], scale[1], scale[2], 1.0)))
        obj.data = baked_mesh
        for modifier in list(obj.modifiers):
            obj.modifiers.remove(modifier)
        obj.scale = (1.0, 1.0, 1.0)
        for child, matrix_world in child_world_matrices:
            child.matrix_world = matrix_world


def normalize_publish_context(bpy: Any) -> list[Any]:
    """Isolate the publish closure, standardize metric scale and ASSET_ROOT entry."""
    targets = _publish_target_objects(bpy)
    if not targets:
        raise PublishValidationError("PUBLISH_ASSET_EMPTY", "No publishable asset objects were found")
    target_ids = {id(obj) for obj in targets}

    for obj in list(bpy.data.objects):
        if id(obj) not in target_ids:
            bpy.data.objects.remove(obj, do_unlink=True)

    scene = bpy.context.scene
    root = bpy.data.collections.get("ASSET_ROOT")
    created_root = root is None
    if root is None:
        root = bpy.data.collections.new("ASSET_ROOT")
    if root.name not in {collection.name for collection in scene.collection.children}:
        scene.collection.children.link(root)

    if created_root:
        for obj in targets:
            for collection in list(obj.users_collection):
                collection.objects.unlink(obj)
            root.objects.link(obj)
    for collection in list(scene.collection.children):
        if collection != root:
            scene.collection.children.unlink(collection)

    unit_settings = scene.unit_settings
    top_level = [obj for obj in targets if getattr(obj, "parent", None) not in targets]
    # 保留作者的建模单位（米/厘米/毫米）：不缩放几何、不改 scale_length、不烘焙变换。
    # 尺寸在 inspection 阶段乘 scale_length 统一换算成米上报，几何保持零修改。
    unit_settings.system = "METRIC"

    bounds = _evaluated_bounds(bpy, targets)
    if bounds is not None:
        from mathutils import Vector  # type: ignore

        low, high = bounds
        offset = Vector((-(low.x + high.x) * 0.5, -(low.y + high.y) * 0.5, -low.z))
        for obj in top_level:
            obj.location = obj.location + offset

    return sorted(targets, key=lambda obj: obj.name)


def _preview_world_bounds(bpy: Any) -> tuple[Any, float]:
    from mathutils import Vector  # type: ignore

    depsgraph = bpy.context.evaluated_depsgraph_get()
    points = []
    for obj in bpy.data.objects:
        if obj.type in {"CAMERA", "LIGHT"}:
            continue
        evaluated = obj.evaluated_get(depsgraph)
        bound_box = getattr(evaluated, "bound_box", None)
        if bound_box is None:
            continue
        points.extend(evaluated.matrix_world @ Vector(corner) for corner in bound_box)
    if not points:
        return Vector((0.0, 0.0, 0.0)), 2.0
    low = Vector(tuple(min(point[index] for point in points) for index in range(3)))
    high = Vector(tuple(max(point[index] for point in points) for index in range(3)))
    center = (low + high) * 0.5
    max_dimension = max(float(high[index] - low[index]) for index in range(3))
    return center, max(max_dimension, 0.1)


def _aim_at(obj: Any, target: Any) -> None:
    direction = target - obj.location
    if direction.length == 0:
        return
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


SUPPORTED_PREVIEW_ENGINES = ("EEVEE", "CYCLES")
_DEFAULT_EEVEE_SAMPLES = 64
_DEFAULT_CYCLES_SAMPLES = 48


def _configure_color_management(bpy: Any, scene: Any) -> dict[str, Any]:
    """Keep the render faithful instead of dim: AgX + a small exposure lift."""
    settings = getattr(scene, "view_settings", None)
    applied: dict[str, Any] = {}
    if settings is None:
        return applied
    for transform in ("AgX", "Filmic", "Standard"):
        try:
            settings.view_transform = transform
            applied["viewTransform"] = transform
            break
        except Exception:
            continue
    for look in ("AgX - Medium High Contrast", "Medium High Contrast", "None"):
        try:
            settings.look = look
            applied["look"] = look
            break
        except Exception:
            continue
    try:
        settings.exposure = 0.0
        applied["exposure"] = 0.0
    except Exception:
        pass
    try:
        settings.gamma = 1.0
        applied["gamma"] = 1.0
    except Exception:
        pass
    return applied


def _apply_render_engine(bpy: Any, scene: Any, engine: str, samples: int) -> str:
    """Select the render engine and sample budget; returns the engine actually used."""
    if engine == "CYCLES":
        scene.render.engine = "CYCLES"
        cycles = getattr(scene, "cycles", None)
        if cycles is not None:
            cycles.device = "CPU"
            cycles.samples = samples
            cycles.use_denoising = True
        return "CYCLES"

    used = "EEVEE"
    for candidate in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"):
        try:
            scene.render.engine = candidate
            used = candidate
            break
        except Exception:
            continue
    eevee = getattr(scene, "eevee", None)
    if eevee is not None:
        # EEVEE Next only lights materials properly with ray tracing enabled.
        if hasattr(eevee, "use_raytracing"):
            eevee.use_raytracing = True
        if hasattr(eevee, "use_shadows"):
            eevee.use_shadows = True
        if hasattr(eevee, "taa_render_samples"):
            eevee.taa_render_samples = samples
    return used


def render_preview_view(
    bpy: Any,
    output_path: str,
    view: str,
    *,
    width: int | None = None,
    height: int | None = None,
    engine: str | None = None,
    samples: int | None = None,
) -> dict[str, Any]:
    """Render one deterministic evidence view without saving the modified scene."""
    from mathutils import Vector  # type: ignore

    directions = {
        "THREE_QUARTER": Vector((1.35, -1.55, 1.05)),
        "FRONT": Vector((0.0, -1.0, 0.0)),
        "BACK": Vector((0.0, 1.0, 0.0)),
        "LEFT": Vector((-1.0, 0.0, 0.0)),
        "RIGHT": Vector((1.0, 0.0, 0.0)),
        "TOP": Vector((0.0, 0.0, 1.0)),
    }
    if view not in directions:
        raise ValueError(f"Unsupported preview view: {view}")

    render_width = int(width) if width else PREVIEW_WIDTH
    render_height = int(height) if height else PREVIEW_HEIGHT
    # Cycles is the default: EEVEE flattens this asset class into a grey card and
    # costs about the same wall time on single assets (sub-second at 512px).
    engine_name = (engine or "CYCLES").upper()
    if engine_name not in SUPPORTED_PREVIEW_ENGINES:
        raise ValueError(f"Unsupported preview engine: {engine}")
    sample_count = int(samples) if samples else (
        _DEFAULT_CYCLES_SAMPLES if engine_name == "CYCLES" else _DEFAULT_EEVEE_SAMPLES
    )

    scene = bpy.context.scene
    center, max_dimension = _preview_world_bounds(bpy)

    # Source lights would make the evidence machine/scene dependent. This worker
    # is isolated and never saves its modified memory back to the source file.
    for obj in bpy.data.objects:
        if obj.type == "LIGHT":
            obj.hide_render = True

    preview_collection = bpy.data.collections.new("__BLENDERMCP_PREVIEW__")
    scene.collection.children.link(preview_collection)

    camera_data = bpy.data.cameras.new("__BLENDERMCP_PREVIEW_CAMERA_DATA__")
    camera = bpy.data.objects.new("__BLENDERMCP_PREVIEW_CAMERA__", camera_data)
    preview_collection.objects.link(camera)
    camera_data.lens = 52.0
    camera_data.clip_start = max(0.001, max_dimension / 1000.0)
    camera_data.clip_end = max(1000.0, max_dimension * 20.0)
    direction = directions[view].normalized()
    camera.location = center + direction * (max_dimension * 2.5 + 0.75)
    _aim_at(camera, center)
    scene.camera = camera

    light_specs = (
        ("KEY", Vector((1.8, -1.4, 2.2)), 900.0, 1.8),
        ("FILL", Vector((-1.5, -0.6, 1.2)), 500.0, 2.2),
        ("RIM", Vector((0.4, 1.8, 2.0)), 700.0, 1.6),
    )
    # Area-light power must track distance squared: the rig sits at a fixed
    # multiple of the asset size, so a fixed wattage makes large assets dark and
    # flat. This keeps illuminance roughly constant across asset scales.
    energy_scale = max(0.25, max_dimension ** 2) * 0.22
    for label, offset, energy, size_scale in light_specs:
        light_data = bpy.data.lights.new(f"__BLENDERMCP_PREVIEW_{label}_DATA__", "AREA")
        light_data.energy = energy * energy_scale
        light_data.shape = "DISK"
        light_data.size = max(0.5, max_dimension * size_scale)
        light = bpy.data.objects.new(f"__BLENDERMCP_PREVIEW_{label}__", light_data)
        preview_collection.objects.link(light)
        light.location = center + offset.normalized() * (max_dimension * 2.2 + 0.5)
        _aim_at(light, center)

    world = bpy.data.worlds.new("__BLENDERMCP_PREVIEW_WORLD__")
    world.use_nodes = True
    background = world.node_tree.nodes.get("Background") if world.node_tree else None
    if background is not None:
        color_input = background.inputs.get("Color")
        strength_input = background.inputs.get("Strength")
        if color_input is not None:
            color_input.default_value = (0.16, 0.16, 0.17, 1.0)
        if strength_input is not None:
            strength_input.default_value = 0.55
    scene.world = world

    used_engine = _apply_render_engine(bpy, scene, engine_name, sample_count)
    color_management = _configure_color_management(bpy, scene)
    scene.render.resolution_x = render_width
    scene.render.resolution_y = render_height
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.film_transparent = False
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    scene.render.filepath = str(target)
    bpy.ops.render.render(write_still=True)
    if not target.is_file():
        raise RuntimeError("Preview render completed without producing PNG")

    return {
        "width": render_width,
        "height": render_height,
        "view": view,
        "engine": used_engine,
        "samples": sample_count,
        **color_management,
    }


def render_main_preview(
    bpy: Any,
    observation: dict[str, Any],
    output_path: str,
    preview_options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Render the standard deterministic three-quarter MAIN image in worker memory."""
    _ = observation
    options = preview_options or {}
    return render_preview_view(
        bpy,
        output_path,
        "THREE_QUARTER",
        width=options.get("width"),
        height=options.get("height"),
        engine=options.get("engine"),
        samples=options.get("samples"),
    )


def _remove_preview_rig(bpy: Any) -> None:
    scene = bpy.context.scene
    if getattr(scene, "camera", None) is not None and scene.camera.name.startswith(
        "__BLENDERMCP_PREVIEW"
    ):
        scene.camera = None
    for obj in list(bpy.data.objects):
        if obj.name.startswith("__BLENDERMCP_PREVIEW"):
            bpy.data.objects.remove(obj, do_unlink=True)
    for collection in list(bpy.data.collections):
        if collection.name.startswith("__BLENDERMCP_PREVIEW"):
            bpy.data.collections.remove(collection)
    world = getattr(scene, "world", None)
    if world is not None and world.name.startswith("__BLENDERMCP_PREVIEW"):
        scene.world = None
        bpy.data.worlds.remove(world)


def pack_self_contained(bpy: Any) -> dict[str, Any]:
    libraries = [str(getattr(library, "filepath", "")) for library in bpy.data.libraries]
    if libraries:
        raise PublishValidationError(
            "PAYLOAD_NOT_SELF_CONTAINED",
            "Linked Blender libraries remain in the publish closure",
        )
    bpy.ops.file.pack_all()
    unpacked_images = []
    for image in bpy.data.images:
        source = str(getattr(image, "source", ""))
        if source not in {"FILE", "SEQUENCE", "MOVIE"}:
            continue
        packed = bool(getattr(image, "packed_file", None)) or bool(
            _as_sequence(getattr(image, "packed_files", None))
        )
        if not packed:
            unpacked_images.append(image.name)
    if unpacked_images:
        raise PublishValidationError(
            "PAYLOAD_NOT_SELF_CONTAINED",
            "Unpacked external images remain: " + ", ".join(sorted(unpacked_images)),
        )
    return {"selfContained": True, "linkedLibraryCount": 0, "unpackedImageCount": 0}


def export_viewer_glb(bpy: Any, target: str | Path) -> dict[str, Any]:
    """Export a derived viewer file. glTF is metres by spec, so the unit conversion happens
    here only; the authoritative *.blend payload keeps the authoring units untouched."""
    path = Path(target)
    try:
        bpy.ops.export_scene.gltf(
            filepath=str(path),
            export_format="GLB",
            use_selection=False,
            export_apply=False,
            export_draco_mesh_compression_enable=True,
            export_draco_mesh_compression_level=6,
            export_image_format="WEBP",
            export_image_quality=90,
        )
    except Exception as error:  # viewer export must never break a publish
        return {"status": "FAILED", "error": f"{type(error).__name__}: {error}"}
    if not path.is_file():
        return {"status": "FAILED", "error": "glTF exporter produced no file"}
    return {"status": "OK", "path": str(path), "size": path.stat().st_size}


def write_publish_payload(bpy: Any, payload_path: str | Path) -> None:
    target = Path(payload_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    bpy.data.libraries.write(
        str(target),
        {bpy.context.scene},
        path_remap="RELATIVE",
        fake_user=True,
        compress=False,
    )
    if not target.is_file():
        raise PublishValidationError(
            "PAYLOAD_WRITE_FAILED", "Blender library write did not create payload.blend"
        )


def compare_publish_facts(
    expected: dict[str, Any],
    reopened: dict[str, Any],
    *,
    dimension_tolerance: float = PUBLISH_DIMENSION_TOLERANCE_METERS,
) -> dict[str, Any]:
    mismatches: list[dict[str, Any]] = []
    scalar_paths = (
        ("structure", "objectCount"),
        ("geometry", "triangleCount"),
        ("materials", "materialCount"),
        ("materials", "materialWorkflow"),
    )
    for section, key in scalar_paths:
        before = expected.get(section, {}).get(key)
        after = reopened.get(section, {}).get(key)
        if before != after:
            mismatches.append({"field": f"{section}.{key}", "expected": before, "actual": after})

    expected_dimensions = expected.get("geometry", {}).get("dimensionsMeters", {})
    reopened_dimensions = reopened.get("geometry", {}).get("dimensionsMeters", {})
    for axis in ("x", "y", "z"):
        before = float(expected_dimensions.get(axis, 0.0) or 0.0)
        after = float(reopened_dimensions.get(axis, 0.0) or 0.0)
        if abs(before - after) > dimension_tolerance:
            mismatches.append(
                {
                    "field": f"geometry.dimensionsMeters.{axis}",
                    "expected": before,
                    "actual": after,
                }
            )
    if mismatches:
        raise PublishValidationError(
            "PAYLOAD_FACT_MISMATCH",
            "Final payload facts differ from prepared publish facts: "
            + json.dumps(mismatches, ensure_ascii=False, sort_keys=True),
        )
    per_object = _object_dimension_mismatches(expected, reopened, dimension_tolerance)
    if per_object:
        raise PublishValidationError(
            "PAYLOAD_OBJECT_DIMENSION_MISMATCH",
            "Reopened payload changed individual object sizes: "
            + json.dumps(per_object, ensure_ascii=False, sort_keys=True),
        )
    return {
        "status": "PASSED",
        "factsVerifiedAfterReopen": True,
        "dimensionToleranceMeters": dimension_tolerance,
        "verifiedFields": [
            "structure.objectCount",
            "geometry.triangleCount",
            "geometry.dimensionsMeters",
            "structure.objects[].dimensionsMeters",
            "materials.materialCount",
            "materials.materialWorkflow",
        ],
    }


def _object_dimension_mismatches(
    expected: dict[str, Any],
    reopened: dict[str, Any],
    tolerance: float,
) -> list[dict[str, Any]]:
    """Every object must keep its size: only a top-level bbox check misses shrunk parts."""

    def by_name(observation: dict[str, Any]) -> dict[str, dict[str, Any]]:
        detail = observation.get("structure", {}).get("objects")
        if isinstance(detail, dict):
            return {str(name): item for name, item in detail.items() if isinstance(item, dict)}
        if isinstance(detail, list):
            return {
                str(item.get("name")): item
                for item in detail
                if isinstance(item, dict) and item.get("name") is not None
            }
        return {}

    before_objects = by_name(expected)
    after_objects = by_name(reopened)
    mismatches: list[dict[str, Any]] = []
    for name, before in before_objects.items():
        after = after_objects.get(name)
        if after is None:
            mismatches.append({"object": name, "field": "missing"})
            continue
        before_dimensions = before.get("dimensionsMeters") or {}
        after_dimensions = after.get("dimensionsMeters") or {}
        for axis in ("x", "y", "z"):
            left = float(before_dimensions.get(axis, 0.0) or 0.0)
            right = float(after_dimensions.get(axis, 0.0) or 0.0)
            if abs(left - right) > tolerance:
                mismatches.append(
                    {
                        "object": name,
                        "field": f"dimensionsMeters.{axis}",
                        "expected": left,
                        "actual": right,
                    }
                )
    return mismatches


def _write_json(path: str | Path, payload: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    os.replace(temporary, target)


def _run_supplemental_view_job(job: dict[str, Any]) -> dict[str, Any]:
    prepare_id = str(job.get("prepareId") or "")
    source_path = str(job.get("sourcePath") or "")
    preview_path = str(job.get("previewPath") or "")
    result_path = str(job.get("resultPath") or "")
    view = str(job.get("view") or "")
    if not prepare_id:
        raise ValueError("job.prepareId is required")
    if view not in SUPPLEMENTAL_VIEWS:
        raise ValueError(f"Unsupported supplemental view: {view}")
    if not source_path or not Path(source_path).is_file():
        raise FileNotFoundError(f"job.sourcePath does not exist: {source_path}")
    if not preview_path:
        raise ValueError("job.previewPath is required")
    if not result_path:
        raise ValueError("job.resultPath is required")

    started = time.perf_counter()
    bpy = _import_bpy()
    try:
        open_started = time.perf_counter()
        bpy.ops.wm.open_mainfile(filepath=source_path)
        open_ms = _elapsed_ms(open_started)
        render_started = time.perf_counter()
        preview_evidence = render_preview_view(bpy, preview_path, view)
        render_ms = _elapsed_ms(render_started)
        result = {
            "status": "READY",
            "prepareId": prepare_id,
            "view": view,
            "previewPath": preview_path,
            "previewEvidence": preview_evidence,
            "timings": {
                "openMs": open_ms,
                "renderMs": render_ms,
                "totalMs": _elapsed_ms(started),
            },
        }
        _write_json(result_path, result)
        return result
    except Exception as exc:
        failed = {
            "status": "FAILED",
            "prepareId": prepare_id,
            "view": view,
            "error": {
                "code": "WORKER_FAILED",
                "message": str(exc),
                "type": type(exc).__name__,
            },
            "timings": {"totalMs": _elapsed_ms(started)},
        }
        try:
            _write_json(result_path, failed)
        except Exception:
            pass
        raise


def run_job(job: dict[str, Any]) -> dict[str, Any]:
    mode = str(job.get("mode") or "PREPARE")
    if mode == "SUPPLEMENTAL_VIEW":
        return _run_supplemental_view_job(job)
    if mode != "PREPARE":
        raise ValueError(f"Unsupported worker mode: {mode}")

    prepare_id = str(job.get("prepareId") or "")
    profile = str(job.get("profile") or "")
    source_path = str(job.get("sourcePath") or "")
    source_kind = str(job.get("sourceKind") or "BLEND_FILE")
    source_display_name = str(job.get("sourceDisplayName") or Path(source_path).name)
    preview_path = str(job.get("previewPath") or "")
    payload_path = str(job.get("payloadPath") or "")
    result_path = str(job.get("resultPath") or "")
    preview_options = job.get("previewOptions") or {}
    if not isinstance(preview_options, dict):
        raise ValueError("job.previewOptions must be an object")

    if not prepare_id:
        raise ValueError("job.prepareId is required")
    if profile not in SUPPORTED_PROFILES:
        raise ValueError(f"Unsupported profile: {profile}")
    if not source_path or not Path(source_path).is_file():
        raise FileNotFoundError(f"job.sourcePath does not exist: {source_path}")
    if not preview_path:
        raise ValueError("job.previewPath is required")
    if profile == "PUBLISH" and not payload_path:
        raise ValueError("job.payloadPath is required for PUBLISH")
    if not result_path:
        raise ValueError("job.resultPath is required")

    started = time.perf_counter()
    bpy = _import_bpy()
    try:
        open_started = time.perf_counter()
        bpy.ops.wm.open_mainfile(filepath=source_path)
        open_ms = _elapsed_ms(open_started)

        # Every profile renders the same isolated asset closure. A CURRENT_SELECTION
        # snapshot carries objects that are not linked into any collection, so
        # without this the preview renders an empty frame and the evidence reports
        # millimetre coordinates as metres.
        closure_objects = normalize_publish_context(bpy)

        inspect_started = time.perf_counter()
        observation = extract_observation(
            bpy,
            prepare_id=prepare_id,
            source_kind=source_kind,
            source_path=source_path,
            source_display_name=source_display_name,
            profile=profile,
            objects=closure_objects,
            observation_scope="PUBLISH_PAYLOAD" if profile == "PUBLISH" else "SOURCE_ASSET",
        )
        inspect_ms = _elapsed_ms(inspect_started)

        pack_ms = 0.0
        pack_evidence: dict[str, Any] | None = None
        if profile == "PUBLISH":
            pack_started = time.perf_counter()
            pack_evidence = pack_self_contained(bpy)
            pack_ms = _elapsed_ms(pack_started)

        preview_started = time.perf_counter()
        preview_evidence = render_main_preview(bpy, observation, preview_path, preview_options)
        preview_ms = _elapsed_ms(preview_started)
        observation["previewEvidence"] = {
            "presetVersion": PREVIEW_PRESET_VERSION,
            "main": preview_evidence,
            "supplementalViews": [],
        }

        timings = {
            "openMs": open_ms,
            "inspectMs": inspect_ms,
            "previewMs": preview_ms,
        }
        result: dict[str, Any] = {
            "status": "READY",
            "prepareId": prepare_id,
            "profile": profile,
            "observation": observation,
            "previewPath": preview_path,
            "previewOptions": preview_options,
        }

        if profile == "PUBLISH":
            _remove_preview_rig(bpy)
            payload_write_started = time.perf_counter()
            write_publish_payload(bpy, payload_path)
            payload_write_ms = _elapsed_ms(payload_write_started)

            viewer_started = time.perf_counter()
            viewer_result = export_viewer_glb(bpy, Path(payload_path).with_suffix(".glb"))
            viewer_ms = _elapsed_ms(viewer_started)

            payload_reopen_started = time.perf_counter()
            bpy.ops.wm.open_mainfile(filepath=payload_path)
            payload_reopen_ms = _elapsed_ms(payload_reopen_started)
            root = bpy.data.collections.get("ASSET_ROOT")
            if root is None:
                raise PublishValidationError(
                    "PAYLOAD_ENTRY_MISSING", "Final payload does not contain ASSET_ROOT"
                )
            reopened_objects = _collection_objects(root)
            reopened_observation = extract_observation(
                bpy,
                prepare_id=prepare_id,
                source_kind=source_kind,
                source_path=source_path,
                source_display_name=source_display_name,
                profile=profile,
                objects=reopened_objects,
                observation_scope="PUBLISH_PAYLOAD",
            )
            validation = compare_publish_facts(
                observation,
                reopened_observation,
                dimension_tolerance=PUBLISH_DIMENSION_TOLERANCE_METERS,
            )
            validation["entryType"] = "COLLECTION"
            validation["entryName"] = "ASSET_ROOT"
            validation["selfContained"] = bool(pack_evidence and pack_evidence["selfContained"])

            hash_started = time.perf_counter()
            payload_file = Path(payload_path)
            payload_sha256 = _file_sha256(payload_file)
            payload_size = payload_file.stat().st_size
            hash_ms = _elapsed_ms(hash_started)
            payload_evidence = {
                "format": "BLEND",
                "compression": "NONE",
                "generatedBlenderVersion": bpy.app.version_string,
                "sha256": payload_sha256,
                "size": payload_size,
                "factsVerifiedAfterReopen": True,
            }
            observation["payloadEvidence"] = payload_evidence
            result["payloadPath"] = payload_path
            result["payloadEvidence"] = payload_evidence
            result["viewer"] = viewer_result
            if viewer_result.get("status") == "OK":
                viewer_file = Path(str(viewer_result["path"]))
                result["viewerPath"] = str(viewer_file)
                result["viewerEvidence"] = {
                    "format": "GLB",
                    "sha256": _file_sha256(viewer_file),
                    "size": viewer_file.stat().st_size,
                    "derivedFromPayloadSha256": payload_sha256,
                    "compression": "DRACO",
                    # glTF positions stay in authoring units; node transforms carry the
                    # conversion, so the viewer-space box must match these metres.
                    "expectedDimensionsMeters": observation.get("geometry", {}).get(
                        "dimensionsMeters"
                    ),
                }
            result["validation"] = validation
            timings.update(
                {
                    "packMs": pack_ms,
                    "payloadWriteMs": payload_write_ms,
                    "payloadReopenMs": payload_reopen_ms,
                    "hashMs": hash_ms,
                }
            )

        observation_cache_path = str(job.get("observationCachePath") or "")
        if observation_cache_path:
            observation_cache = {
                "prepareId": prepare_id,
                "sections": {
                    "STRUCTURE": observation["structure"],
                    "GEOMETRY": observation["geometry"],
                    "MATERIALS": observation["materials"],
                    "DEFORMATION": observation["deformation"],
                },
            }
            item_key = job.get("itemKey")
            if isinstance(item_key, str) and item_key:
                observation_cache["itemKey"] = item_key
            _write_json(observation_cache_path, observation_cache)
            result["observationCachePath"] = observation_cache_path

        timings["totalMs"] = _elapsed_ms(started)
        result["timings"] = timings
        _write_json(result_path, result)
        return result
    except Exception as exc:
        failed = {
            "status": "FAILED",
            "prepareId": prepare_id,
            "profile": profile,
            "error": {
                "code": exc.code if isinstance(exc, PublishValidationError) else "WORKER_FAILED",
                "message": str(exc),
                "type": type(exc).__name__,
            },
            "timings": {"totalMs": _elapsed_ms(started)},
        }
        try:
            _write_json(result_path, failed)
        except Exception:
            pass
        raise


def build_status() -> dict[str, object]:
    return {
        "workerProtocolVersion": WORKER_PROTOCOL_VERSION,
        "supportedProfiles": list(SUPPORTED_PROFILES),
        "observationSchemaVersion": OBSERVATION_SCHEMA_VERSION,
        "analyzerVersion": ANALYZER_VERSION,
        "previewPresetVersion": PREVIEW_PRESET_VERSION,
    }


def _script_args(argv: list[str] | None) -> list[str]:
    if argv is not None:
        return argv
    values = list(sys.argv[1:])
    if "--" in values:
        values = values[values.index("--") + 1 :]
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="BlenderMCP asset preparation worker")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--status",
        action="store_true",
        help="Print worker capability metadata as JSON.",
    )
    group.add_argument("--job", help="Path to a prepare job JSON file.")
    args = parser.parse_args(_script_args(argv))
    if args.status:
        print(json.dumps(build_status(), sort_keys=True))
        return 0

    job_path = Path(args.job)
    try:
        job = json.loads(job_path.read_text(encoding="utf-8"))
        result = run_job(job)
    except Exception as exc:
        print(
            json.dumps(
                {
                    "status": "FAILED",
                    "code": "WORKER_FAILED",
                    "message": str(exc),
                    "type": type(exc).__name__,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(
        json.dumps(
            {
                "status": result["status"],
                "prepareId": result["prepareId"],
                "profile": result["profile"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
